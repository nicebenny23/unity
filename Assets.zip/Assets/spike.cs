using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spike : MonoBehaviour
{
    public float damageamount;
    public float kbforce;
    public points player;
    public GameObject coinprefab;
    public float coinflyamount;
    public LayerMask mask;
    public float range;
  
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    private void OnTriggerEnter2D(Collider2D collision)
    { 
        if(collision.GetComponent<enemyhealth>().health < 1) { 
         GameObject coin = Instantiate(coinprefab, transform.position, new Quaternion(0,0,0,1));
                coin.gameObject.SetActive(true);
                coin.GetComponent<Rigidbody2D>().velocity = Vector2.up * coinflyamount;
                coin.transform.position += Vector3.up * 2;
                player.point += 10;
                Destroy(collision.gameObject);
            }
            else
            {

                
                collision.gameObject.GetComponent<Rigidbody2D>().velocity += (Vector2.right * kbforce * Mathf.Sign(collision.transform.position.x - transform.position.x));
                collision.gameObject.GetComponent<Rigidbody2D>().velocity += (Vector2.up * kbforce * Mathf.Sign(collision.transform.position.y - transform.position.y));
                collision.gameObject.GetComponent<enemyhealth>().health = collision.gameObject.GetComponent<enemyhealth>().health - damageamount;
            }
                

 
    }
    
}

         
        
    

