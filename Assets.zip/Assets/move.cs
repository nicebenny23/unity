using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    public Rigidbody2D rb;
    public float sx;
    public float sy;
    public float max;
    public float jt;
    public float jtmax;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        jt = jt - .01f;
        if (Input.GetKey(KeyCode.UpArrow) & jt <0 )
        {
            rb.velocity += (Vector2.up * sy);
            jt = jtmax;
        }
        if(Mathf.Abs( rb.velocity.x)<max){
           rb.velocity += ( Vector2.right *(Input.GetAxis("Horizontal") * sx));
        }
    }
}
