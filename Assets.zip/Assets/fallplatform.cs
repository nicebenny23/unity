using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fallplatform : MonoBehaviour
{
    public float waitingtime;
    public Rigidbody2D rb;
    public float fallspeed;
    public float xspeed;
    public float rotspeed;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        
    }
    private void OnCollisionStay2D(Collision2D collision)
    {
       

        if (collision.gameObject.CompareTag("Player"))
        {



            rb.velocity =  new Vector2 (xspeed,fallspeed);
            transform.Rotate(0, 0, rotspeed);
            Destroy(gameObject,waitingtime);
        }
    }
}
