using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hpboost : MonoBehaviour
{
    public float healamount;
    public float pointamount;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
   
    }

    private void OnCollisionStay2D(Collision2D collision)
    {


        if (collision.gameObject.CompareTag("Player"))
        {


            collision.gameObject.GetComponent<health>().hp = collision.gameObject.GetComponent<health>().hp + healamount;
            collision.gameObject.GetComponent<points>().point = collision.gameObject.GetComponent <points>().point + pointamount;
            Destroy(gameObject);
        }
    }
}