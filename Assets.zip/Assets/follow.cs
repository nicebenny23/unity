using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class follow : MonoBehaviour
{
    public float speed;
    public float tba;
    public float time;
    public Transform player;
    public float damageamount;
    public float kbforce;
    public float distance;
    public bool forget ;
    public float jp;
    public float jh;
    public bool canattack = false;
    // Start is called before the first frame update
    void Start()
    {
       
        
    }

    // Update is called once per frame
    void Update()
    {

        time--;
        if (time < 0)
        {

            if (Vector2.Distance(transform.position, player.position) < distance)
            {
                if (.5f - Random.Range(0,jp) < 0)
                {

                    gameObject.GetComponent<Rigidbody2D>().velocity += Vector2.up * (1 + jh);
        }
                canattack = true;
            }

            else if (forget == true)
            {
                canattack = false;

            }
            if (canattack == true)
            {
                transform.Translate(Vector2.right * (speed * Mathf.Sign(player.position.x - transform.position.x)));
            }
            }
      
        
    }
    private void OnTriggerStay2D(Collider2D collision)
    {


        
            if (collision.gameObject.CompareTag("Player"))
            {
                if (time < 0)
                {
                collision.gameObject.GetComponent<Rigidbody2D>().velocity += (Vector2.up * kbforce * Mathf.Sign(collision.transform.position.y - transform.position.y));
               
                collision.gameObject.GetComponent<Rigidbody2D>().velocity +=(Vector2.right *kbforce* Mathf.Sign(player.position.x - transform.position.x));
                    collision.gameObject.GetComponent<health>().hp = collision.gameObject.GetComponent<health>().hp - damageamount;
                    time = tba;
                }
            }
        
    }
   
        
    
}
