using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyhealth : MonoBehaviour
{
    
    private GameObject coinprefab;
    public float health;
    // Start is called before the first frame update
    void Start()
    {
        coinprefab = GameObject.Find("coin (3)");
    }

    // Update is called once per frame


    public void takedamage(int damage)
    {
        health -= damage;
        if (health < 0)
        {
            GameObject coin = Instantiate(coinprefab, transform.position, new Quaternion(0, 0, 0, 1));
            coin.gameObject.SetActive(true);
            coin.GetComponent<Rigidbody2D>().velocity = Vector2.up * 2;
            coin.transform.position += Vector3.up * 2;

            Destroy(gameObject);
        }

        else
        {


        }
    }      
}
